// 1. Define your hit list of annoying CSS selectors
const selectorsToRemove = [
  '#masthead-ad',
  'ytd-rich-item-renderer.style-scope.ytd-rich-grid-row #content:has(.ytd-display-ad-renderer)',
  '.video-ads.ytp-ad-module',
  'tp-yt-paper-dialog:has(yt-mealbar-promo-renderer)',
  'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
  '#related #player-ads',
  '#related ytd-ad-slot-renderer',
  'ytd-ad-slot-renderer',
  'yt-mealbar-promo-renderer',
  'ytd-popup-container:has(a[href="/premium"])',
  'ad-slot-renderer',
  'ytm-companion-ad-renderer',
  '#related #-ad-',
  '#mealbar-promo-renderer',
  'ytd-popup-container tp-yt-paper-dialog'
];

// Compile it once for better performance
const compiledSelector = selectorsToRemove.join(', ');

const adBlockAlgorithms = [
  {
    id: 'removeAnnoyingPopups',
    run: () => {
      const removed = [];
      // Clean up anything matching your hit list
      document.querySelectorAll(compiledSelector).forEach(el => {
        el.remove();
        removed.push(el);
      });
      return removed.length > 0;
    }
  },
  {
    id: 'removeDialog',
    run: () => {
      const removed = [];
      document.querySelectorAll(
        'tp-yt-paper-dialog[style-target="host"][role="dialog"][tabindex="-1"][style*="position: fixed; top: 242.25px; left: 270px;"]'
      ).forEach(el => {
        el.remove();
        removed.push(el);
      });
      return removed.length > 0;
    }
  },
  {
    id: 'skipVideoAd',
    run: () => {
      const ad = document.querySelector('.ad-showing');
      const video = document.querySelector('video');
      if (ad && video && video.duration > 0) {
        video.currentTime = video.duration;
        return true;
      }
      return false;
    }
  },
  {
    id: 'setYouTubeCookie',
    run: () => {
      if (!document.cookie.includes('VISITOR_INFO1_LIVE=oKckVSqvaGw')) {
        document.cookie = 'VISITOR_INFO1_LIVE=oKckVSqvaGw; path=/; domain=.youtube.com';
        return true;
      }
      return false;
    }
  }
];

function tryAdBlocking() {
  for (const algo of adBlockAlgorithms) {
    try {
      if (algo.run()) {
        return true;
      }
    } catch (error) {
      console.warn(`Ad block algorithm failed: ${algo.id}`, error);
    }
  }
  return false;
}

let clearAdInterval;

function startAdSkipping() {
  // Clear any existing interval before starting a new one to prevent duplicates
  if (clearAdInterval) clearInterval(clearAdInterval);
  
  clearAdInterval = setInterval(() => {
    tryAdBlocking();
  }, 500);
}

function stopAdSkipping() {
  if (clearAdInterval) {
    clearInterval(clearAdInterval);
    clearAdInterval = undefined;
  }
}

function initAdBlock() {
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get(['adBlockEnabled'], (result) => {
      if (result.adBlockEnabled !== false) {
        tryAdBlocking();
        startAdSkipping();
      }
    });
  } else {
    console.warn('chrome.storage not available in content script');
    // Fallback for local testing outside of extension environment
    tryAdBlocking();
    startAdSkipping();
  }
}

if (typeof chrome !== 'undefined' && chrome.runtime) {
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'toggleAdBlock') {
      if (message.enabled) {
        tryAdBlocking();
        startAdSkipping();
      } else {
        stopAdSkipping();
      }
    }
  });
} else {
  console.warn('chrome.runtime not available in content script');
}

initAdBlock();