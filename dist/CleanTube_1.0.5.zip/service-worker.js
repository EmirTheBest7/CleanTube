// src/background/service-worker.js
// Background service worker — MV3. No ES module imports (classic SW).
// Responsibilities: relay settings to all YouTube tabs, maintain stat counters.

'use strict';

const STORAGE_KEY = 'ct_settings';
const STATS_KEY   = 'ct_stats';

const DEFAULTS = {
  adBlockEnabled:    true,
  skipVideoAds:      true,
  removeOverlayAds:  true,
  removeHomepageAds: true,
  removeSidebarAds:  true,
  removeShortsAds:   true,
  pipButtonEnabled:  true,
  removeTrackers:    true,
  customLogoEnabled: false,
};

const STAT_DEFAULTS = {
  adsBlocked: 0,
  videosSkipped: 0,
  overlaysRemoved: 0,
  sessionStart: Date.now(),
};

// ─── Message Router ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true;
});

async function handleMessage(message) {
  switch (message.type) {

    case 'CT_SETTINGS_CHANGED': {
      // Fan out to all active YouTube tabs
      const tabs = await chrome.tabs.query({ url: '*://*.youtube.com/*' });
      const promises = tabs.map((tab) =>
        chrome.tabs.sendMessage(tab.id, message).catch(() => {})
      );
      await Promise.all(promises);
      return { ok: true };
    }

    case 'CT_GET_STATS': {
      const result = await chrome.storage.local.get(STATS_KEY);
      return { ok: true, data: { ...STAT_DEFAULTS, ...(result[STATS_KEY] || {}) } };
    }

    case 'CT_RESET_STATS': {
      const fresh = { ...STAT_DEFAULTS, sessionStart: Date.now() };
      await chrome.storage.local.set({ [STATS_KEY]: fresh });
      return { ok: true, data: fresh };
    }

    case 'CT_BUMP_STAT': {
      const result = await chrome.storage.local.get(STATS_KEY);
      const stats = { ...STAT_DEFAULTS, ...(result[STATS_KEY] || {}) };
      stats[message.key] = (stats[message.key] || 0) + (message.amount || 1);
      await chrome.storage.local.set({ [STATS_KEY]: stats });
      return { ok: true, data: stats };
    }

    default:
      return { ok: false, error: 'unknown message type: ' + message.type };
  }
}

// ─── Install Handler ──────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') {
    // Seed defaults so storage reads never return undefined
    const existing = await chrome.storage.local.get([STORAGE_KEY, STATS_KEY]);
    if (!existing[STORAGE_KEY]) {
      await chrome.storage.local.set({ [STORAGE_KEY]: { ...DEFAULTS } });
    }
    if (!existing[STATS_KEY]) {
      await chrome.storage.local.set({ [STATS_KEY]: { ...STAT_DEFAULTS } });
    }
    console.log('[CleanTube] Installed v2.0.0');
  }
});
