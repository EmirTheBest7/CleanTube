// src/popup/popup.js
// Popup controller. Reads/writes settings via chrome.storage,
// fans changes to content script via background service worker.

const STORAGE_KEY = 'ct_settings';
const STATS_KEY   = 'ct_stats';

const DEFAULTS = {
  adBlockEnabled:     true,
  skipVideoAds:       true,
  removeOverlayAds:   true,
  removeHomepageAds:  true,
  removeSidebarAds:   true,
  removeShortsAds:    true,
  pipButtonEnabled:   true,
  removeTrackers:     true,
  customLogoEnabled:  false,
};

// ─── DOM Refs ─────────────────────────────────────────────────────────────────

const els = {
  statusBadge:     document.getElementById('statusBadge'),
  statusText:      document.getElementById('statusText'),
  statAds:         document.getElementById('statAds'),
  statSkipped:     document.getElementById('statSkipped'),
  footerStatus:    document.getElementById('footerStatus'),

  toggleMain:      document.getElementById('toggleMain'),
  toggleSkipVideo: document.getElementById('toggleSkipVideo'),
  toggleOverlay:   document.getElementById('toggleOverlay'),
  toggleHomepage:  document.getElementById('toggleHomepage'),
  toggleSidebar:   document.getElementById('toggleSidebar'),
  toggleShorts:    document.getElementById('toggleShorts'),
  togglePiP:       document.getElementById('togglePiP'),
  toggleLogo:      document.getElementById('toggleLogo'),

  btnReload:       document.getElementById('btnReload'),
  btnResetStats:   document.getElementById('btnResetStats'),
};

// ─── State ─────────────────────────────────────────────────────────────────────

let settings = { ...DEFAULTS };

// ─── Tabs ─────────────────────────────────────────────────────────────────────

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => {
      t.classList.remove('active');
      t.setAttribute('aria-selected', 'false');
    });
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));

    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');

    const panelId = `panel-${tab.dataset.tab}`;
    document.getElementById(panelId)?.classList.add('active');
  });
});

// ─── UI Sync ──────────────────────────────────────────────────────────────────

function applySettingsToUI(s) {
  els.toggleMain.checked      = s.adBlockEnabled;
  els.toggleSkipVideo.checked = s.skipVideoAds;
  els.toggleOverlay.checked   = s.removeOverlayAds;
  els.toggleHomepage.checked  = s.removeHomepageAds;
  els.toggleSidebar.checked   = s.removeSidebarAds;
  els.toggleShorts.checked    = s.removeShortsAds;
  els.togglePiP.checked       = s.pipButtonEnabled;
  els.toggleLogo.checked      = s.customLogoEnabled;

  updateStatusBadge(s.adBlockEnabled);
}

function updateStatusBadge(enabled) {
  els.statusBadge.className = `status-badge ${enabled ? 'active' : 'paused'}`;
  els.statusText.textContent = enabled ? 'Active' : 'Paused';
}

function renderStats(stats) {
  els.statAds.textContent     = fmt(stats.adsBlocked    || 0);
  els.statSkipped.textContent = fmt(stats.videosSkipped || 0);
}

function fmt(n) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'k';
  return String(n);
}

// ─── Persist + Notify ─────────────────────────────────────────────────────────

async function saveAndBroadcast() {
  await chrome.storage.local.set({ [STORAGE_KEY]: settings });

  // Notify all YouTube tabs via background
  chrome.runtime.sendMessage({
    type: 'CT_SETTINGS_CHANGED',
    settings,
  }).catch(() => {});
}

// ─── Toggle Wiring ────────────────────────────────────────────────────────────

function bindToggle(el, key) {
  el.addEventListener('change', async () => {
    settings[key] = el.checked;
    if (key === 'adBlockEnabled') updateStatusBadge(el.checked);
    await saveAndBroadcast();
  });
}

bindToggle(els.toggleMain,      'adBlockEnabled');
bindToggle(els.toggleSkipVideo, 'skipVideoAds');
bindToggle(els.toggleOverlay,   'removeOverlayAds');
bindToggle(els.toggleHomepage,  'removeHomepageAds');
bindToggle(els.toggleSidebar,   'removeSidebarAds');
bindToggle(els.toggleShorts,    'removeShortsAds');
bindToggle(els.togglePiP,       'pipButtonEnabled');
bindToggle(els.toggleLogo,      'customLogoEnabled');

// ─── Actions ──────────────────────────────────────────────────────────────────

els.btnReload.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.url?.includes('youtube.com')) {
      chrome.tabs.reload(tabs[0].id);
      window.close();
    }
  });
});

els.btnResetStats.addEventListener('click', async () => {
  const fresh = { adsBlocked: 0, videosSkipped: 0, overlaysRemoved: 0, sessionStart: Date.now() };
  await chrome.storage.local.set({ [STATS_KEY]: fresh });
  renderStats(fresh);
});

// ─── Footer: show if current tab is YouTube ──────────────────────────────────

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || '';
  if (url.includes('youtube.com')) {
    els.footerStatus.textContent = 'Active on this tab';
    els.footerStatus.style.color = 'var(--green)';
  } else {
    els.footerStatus.textContent = 'Not on YouTube';
  }
});

// ─── Boot ─────────────────────────────────────────────────────────────────────

async function boot() {
  const [settingsRes, statsRes] = await Promise.all([
    chrome.storage.local.get(STORAGE_KEY),
    chrome.storage.local.get(STATS_KEY),
  ]);

  settings = { ...DEFAULTS, ...(settingsRes[STORAGE_KEY] || {}) };
  applySettingsToUI(settings);
  renderStats(statsRes[STATS_KEY] || {});
}

boot().catch(console.warn);
